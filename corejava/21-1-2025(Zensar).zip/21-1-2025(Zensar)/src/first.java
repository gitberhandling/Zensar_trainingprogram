
/**
 * 
 */
public class first {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello world");
		System.out.println("This is the first program");
		System.out.println("This is the third line of program");
		
		
	
	}
	
	
}
