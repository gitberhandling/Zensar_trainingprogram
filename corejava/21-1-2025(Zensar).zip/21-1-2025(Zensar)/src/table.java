
public class table {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	for(int i = 0;i<11;i++ ) {	
		for (int j =0;j<11;j++) {
			System.out.println(i+"*"+j+"= "+i*j);
		}
	
	}
	}

}
