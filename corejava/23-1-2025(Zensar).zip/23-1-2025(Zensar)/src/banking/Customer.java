package banking;




class Customer {
    String name;
    String email;
    BankAccount[] accounts; 
     int accountCount;

    public Customer(String name, String email, int maxAccounts) {
        this.name = name;
        this.email = email;
        this.accounts = new BankAccount[maxAccounts]; 
        this.accountCount = 0;
    }

    public void createSavingsAccount(String accountNumber, double initialBalance) {
        if (accountCount < accounts.length) {
            SavingsAccount account = new SavingsAccount(accountNumber, initialBalance, this.name);
            accounts[accountCount++] = account; 
        } else {
            System.out.println("Cannot create more accounts.");
        }
    }

    public void createCurrentAccount(String accountNumber, double initialBalance) {
        if (accountCount < accounts.length) {
            CurrentAccount account = new CurrentAccount(accountNumber, initialBalance, this.name);
            accounts[accountCount++] = account; 
            System.out.println("Cannot create more accounts.");
        }
    }

    public void displayCustomerAccounts() {
        if (accountCount == 0) {
            System.out.println("No accounts available.");
        } else {
            for (int i = 0; i < accountCount; i++) {
                accounts[i].displayAccountDetails();
            }
        }
    }

    public BankAccount[] getAccounts() {
        return accounts;
    }
}