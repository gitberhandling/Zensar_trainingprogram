package banking;

public class BankingSystem {
    public static void main(String[] args) {

        Customer customer = new Customer("Ankush Jaykar", "ankushjaykar.com", 3);

        
        customer.createSavingsAccount("S12345", 5000.0);
        customer.createCurrentAccount("C12345", 2000.0);
        SavingsAccount savings = (SavingsAccount) customer.getAccounts()[0];
        savings.deposit(1000.0);
        customer.displayCustomerAccounts();

        savings.applyInterest();

        customer.displayCustomerAccounts();

        CurrentAccount current = (CurrentAccount) customer.getAccounts()[1];
        current.withdraw(500.0);
        customer.displayCustomerAccounts();
    }
}