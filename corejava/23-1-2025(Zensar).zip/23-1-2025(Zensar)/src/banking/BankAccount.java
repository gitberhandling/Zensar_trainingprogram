package banking;
abstract class BankAccount {
     String accountNumber;
   double balance;
    String accountHolderName;

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Not enough funds");
        }
    }

    public void displayAccountDetails() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
        System.out.println("Account Holder: " + accountHolderName);
    }

    public double getBalance() {
        return balance;
    }

    public abstract void applyInterest();
}
