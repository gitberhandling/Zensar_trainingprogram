
public class inheritance {

	public static void main(String[] args) {
		Animal animal = new Animal("Generic Animal ");
		animal.makeSound();
		
		
		//create a dog object
		dog Dog = new dog("Buddy ");
		Dog.makeSound();

	}

}
